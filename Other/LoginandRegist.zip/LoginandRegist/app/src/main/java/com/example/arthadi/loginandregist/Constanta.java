package com.example.arthadi.loginandregist;

/**
 * Created by faisalrizarakhmat on 25/01/18.
 */

public class Constanta {

    public static final String URL_Con = "http://172.20.10.3/mecsmoneydata/grabdata.php";

}
