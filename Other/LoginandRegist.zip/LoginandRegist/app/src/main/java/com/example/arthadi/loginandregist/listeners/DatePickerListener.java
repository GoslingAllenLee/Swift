package com.example.arthadi.loginandregist.listeners;

/**
 * Created by Yohanes Himawan K on 6/20/2017.
 */

public interface DatePickerListener {
    public void onDateSet(int year , int month, int day);
}
