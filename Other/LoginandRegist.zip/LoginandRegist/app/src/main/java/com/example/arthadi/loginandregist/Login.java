package com.example.arthadi.loginandregist;

/**
 * Created by Arthadi on 21/03/2017.
 */

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import static android.content.ContentValues.TAG;


public class Login extends Fragment implements View.OnClickListener
{
    private static final String TAG = "Login";
    private EditText edtEmail, edtPwd;
    private Button btn_login;
    private FirebaseAuth auth;
    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.log_in, container, false);
        auth = FirebaseAuth.getInstance();


//        if(auth.getCurrentUser() != null)
//        {
//            //close this activity
//            getActivity().finish();
//            //opening profile activity
//            startActivity(new Intent(getContext(), HomeActivity.class));
//        }

        edtEmail = (EditText) rootView.findViewById(R.id.edt_email);
        edtPwd = (EditText) rootView.findViewById(R.id.edt_pwd);
        btn_login = (Button) rootView.findViewById(R.id.btn_login);

        btn_login.setOnClickListener(this);

        return rootView;
    }

    private void userLogin()
    {
        String email = edtEmail.getText().toString().trim();
        String password  = edtPwd.getText().toString().trim();
        progressDialog = new ProgressDialog(getActivity());

        if(TextUtils.isEmpty(email)){
            Toast.makeText(getContext(),"Please enter email",Toast.LENGTH_LONG).show();
            return;
        }

        if(TextUtils.isEmpty(password)){
            Toast.makeText(getContext(),"Please enter password",Toast.LENGTH_LONG).show();
            return;
        }

        progressDialog.setMessage("Login Please Wait...");
        progressDialog.show();

        auth.signInWithEmailAndPassword(email,password).addOnCompleteListener((Activity) getContext(),
                new OnCompleteListener<AuthResult>()
        {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                //checking if success
                if(task.isSuccessful())
                {
                    getActivity().finish();
                    startActivity(new Intent(getContext(), HomeActivity.class));
                }
                else
                {
                    //display some message here
                    Toast.makeText(getActivity(),"Login Failed",Toast.LENGTH_LONG).show();
                }
                progressDialog.dismiss();
            }
        });
    }


    @Override
    public void onClick(View v)
    {
        userLogin();
    }
}
