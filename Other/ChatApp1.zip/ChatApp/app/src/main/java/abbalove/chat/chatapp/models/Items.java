package abbalove.chat.chatapp.models;

/**
 * Created by Alfian on 1/11/2018.
 */

public class Items {
    public String nama;


    public String pembuat;
    public String harga;
    public String image;
}
