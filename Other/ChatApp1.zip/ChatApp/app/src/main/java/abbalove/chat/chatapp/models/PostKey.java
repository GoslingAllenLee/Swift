package abbalove.chat.chatapp.models;

/**
 * Created by Asus on 11/15/2017.
 */

public class PostKey {
    public String key;
}
