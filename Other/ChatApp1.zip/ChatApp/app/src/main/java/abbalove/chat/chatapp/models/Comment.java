package abbalove.chat.chatapp.models;

/**
 * Created by faisalrizarakhmat on 27/01/18.
 */

public class Comment {
    public String username;
    public String content;
}
