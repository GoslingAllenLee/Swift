package abbalove.chat.chatapp.models;

/**
 * Created by Asus on 11/15/2017.
 */

public class Post {
    public String key;
    public String title;
    public String content;
    public String userid;
    public String image;

//    public Post() {
//        // empty default constructor, necessary for Firebase to be able to deserialize blog posts
//    }
//
//    public String getKey() {
//        return key;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public String getContent() {
//        return content;
//    }
//
//    public String getuserId() {
//        return userid;
//    }
//
//    public String getImage() {
//        return image;
//    }

}
