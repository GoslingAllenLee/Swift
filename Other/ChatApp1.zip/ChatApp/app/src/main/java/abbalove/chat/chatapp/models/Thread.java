package abbalove.chat.chatapp.models;

/**
 * Created by Alfian on 1/17/2018.
 */

public class Thread {

    public String title;
    public String content;
    public String userid;
    public String image;

}
