package abbalove.chat.chatapp.models;

/**
 * Created by Alfian on 1/17/2018.
 */

public class WorldPost {

    public String username;
    public String content;
}
